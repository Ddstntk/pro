<?php

/* @WebProfiler/Icon/translation.svg */
class __TwigTemplate_b3c92817947e1997b11771ea455652ea68e6381a2f721a09a399a03676f99aa5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Icon/translation.svg"));

        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Icon/translation.svg"));

        // line 1
        echo "<svg version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" x=\"0px\" y=\"0px\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" enable-background=\"new 0 0 24 24\" xml:space=\"preserve\">
<path fill=\"#AAAAAA\" d=\"M5.4,6H7v0.3c0,1.2-0.7,1.9-1.7,1.9c-1.1,0-1.4-0.4-1.4-1.1C3.9,6.2,4.5,6,5.4,6z M9.2,0H2.7
    C1.2,0,0,0.9,0,2.4v6.5C0,10.4,1.2,11,2.7,11h1.2l3.3,3.2C7.6,14.4,8,14.5,8,14.1c0-1.4,0-2.8,0-4.2c0-0.4,0-0.7,0.1-1.1
    c-0.1,0-0.3,0-0.4,0C7.4,8.9,7,8.7,7,8.4V7.9c0,0.7-1,1-1.8,1c-1.5,0-2.4-0.7-2.4-2c0-1.3,1.1-2,2.6-2H7V4.5c0-1-0.4-1.6-1.5-1.6
    C4.8,2.9,4.4,3.1,4,3.6C3.8,3.8,3.8,3.8,3.7,3.8c-0.2,0-0.4-0.2-0.4-0.4c0-0.1,0-0.2,0.1-0.2C3.8,2.5,4.4,2,5.6,2C7.2,2,8,3,8,4.5v3
    c1-1.4,1.8-2.4,4-2.4c0,0,0-1.9,0-2.7C12,0.9,10.7,0,9.2,0z M20.7,6h-8C10.8,6,9,7.2,9,9v8c0,1.8,2,3.3,4,3.3v3
    c0,0.5,0.5,0.7,0.9,0.3l4-3.7h2.7c1.8,0,3.3-1.2,3.3-3V9C24,7.2,22.5,6,20.7,6z M13,9c0,0,0.6,0,1.1,0h4.8C19.3,9,20,9,20,9v0.8
    c0,0-0.7,0.3-1.1,0.3h-4.8C13.7,10,13,9.7,13,9.7V9z M12.5,16.9c-0.2-0.2-0.3-0.3-0.6-0.5c1-0.8,1.8-2.1,2.2-3.4l0.7,0.3
    C14.2,14.8,13.4,15.9,12.5,16.9z M17,12v4.8c0,0.7-0.2,0.8-1.2,0.8c-0.4,0-1,0-1.4-0.1c0-0.3-0.1-0.4-0.2-0.7
    c0.6,0.1,0.9,0.1,1.4,0.1c0.4,0,0.4,0,0.4-0.3V12h-2.9c-0.4,0-1.1,0.1-1.1,0.1v-0.8c0,0,0.7-0.4,1.1-0.4h6.8c0.5,0,1.1,0.4,1.1,0.4
    v0.8c0,0-0.6-0.1-1.1-0.1H17z M20.7,16.8c-1-1.1-1.6-1.9-2.3-3.6L19,13c0.5,1.1,0.8,1.7,1.4,2.4c0.3,0.3,0.5,0.5,0.8,0.9
    C21.1,16.4,20.9,16.6,20.7,16.8z\"/>
</svg>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Icon/translation.svg";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<svg version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" x=\"0px\" y=\"0px\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" enable-background=\"new 0 0 24 24\" xml:space=\"preserve\">
<path fill=\"#AAAAAA\" d=\"M5.4,6H7v0.3c0,1.2-0.7,1.9-1.7,1.9c-1.1,0-1.4-0.4-1.4-1.1C3.9,6.2,4.5,6,5.4,6z M9.2,0H2.7
    C1.2,0,0,0.9,0,2.4v6.5C0,10.4,1.2,11,2.7,11h1.2l3.3,3.2C7.6,14.4,8,14.5,8,14.1c0-1.4,0-2.8,0-4.2c0-0.4,0-0.7,0.1-1.1
    c-0.1,0-0.3,0-0.4,0C7.4,8.9,7,8.7,7,8.4V7.9c0,0.7-1,1-1.8,1c-1.5,0-2.4-0.7-2.4-2c0-1.3,1.1-2,2.6-2H7V4.5c0-1-0.4-1.6-1.5-1.6
    C4.8,2.9,4.4,3.1,4,3.6C3.8,3.8,3.8,3.8,3.7,3.8c-0.2,0-0.4-0.2-0.4-0.4c0-0.1,0-0.2,0.1-0.2C3.8,2.5,4.4,2,5.6,2C7.2,2,8,3,8,4.5v3
    c1-1.4,1.8-2.4,4-2.4c0,0,0-1.9,0-2.7C12,0.9,10.7,0,9.2,0z M20.7,6h-8C10.8,6,9,7.2,9,9v8c0,1.8,2,3.3,4,3.3v3
    c0,0.5,0.5,0.7,0.9,0.3l4-3.7h2.7c1.8,0,3.3-1.2,3.3-3V9C24,7.2,22.5,6,20.7,6z M13,9c0,0,0.6,0,1.1,0h4.8C19.3,9,20,9,20,9v0.8
    c0,0-0.7,0.3-1.1,0.3h-4.8C13.7,10,13,9.7,13,9.7V9z M12.5,16.9c-0.2-0.2-0.3-0.3-0.6-0.5c1-0.8,1.8-2.1,2.2-3.4l0.7,0.3
    C14.2,14.8,13.4,15.9,12.5,16.9z M17,12v4.8c0,0.7-0.2,0.8-1.2,0.8c-0.4,0-1,0-1.4-0.1c0-0.3-0.1-0.4-0.2-0.7
    c0.6,0.1,0.9,0.1,1.4,0.1c0.4,0,0.4,0,0.4-0.3V12h-2.9c-0.4,0-1.1,0.1-1.1,0.1v-0.8c0,0,0.7-0.4,1.1-0.4h6.8c0.5,0,1.1,0.4,1.1,0.4
    v0.8c0,0-0.6-0.1-1.1-0.1H17z M20.7,16.8c-1-1.1-1.6-1.9-2.3-3.6L19,13c0.5,1.1,0.8,1.7,1.4,2.4c0.3,0.3,0.5,0.5,0.8,0.9
    C21.1,16.4,20.9,16.6,20.7,16.8z\"/>
</svg>
", "@WebProfiler/Icon/translation.svg", "/home/h4ck3r/PhpstormProjects/Pro/app/vendor/symfony/web-profiler-bundle/Resources/views/Icon/translation.svg");
    }
}
