<?php

/* base.html.twig */
class __TwigTemplate_d9f4500af42297d387b2d61772628418b901338f2d8f3d268bd97cb954e1bc89 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'name' => array($this, 'block_name'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">
<head>
    <meta charset=\"utf-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>";
        // line 8
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
    ";
        // line 9
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 20
        echo "    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script
            src=\"https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js\"></script>
    <script
            src=\"https://oss.maxcdn.com/respond/1.4.2/respond.min.js\"></script>

    <![endif]-->
</head>
<body>

<div class=\"navbar fixed-top\">
    <a href=\"index.html\">Strona domowa</a>
    <a href=\"friends.html\">Znajomi</a>
    <a href=\"chat.html\">Wiadomości</a>
</div>

<div class=\"sidenav col-2\">
    <img class=\"img-fluid \" style=\"width: 100%\"
         src=\"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSxQhGXAcJBNKSrbAA3LowecuQDGJkxUHpOpu-t1dP0kctRBWYx\">
    ";
        // line 41
        $this->displayBlock('name', $context, $blocks);
        // line 42
        echo "    <a href=\"#\">Twój profil</a>
    <a href=\"#\">Zdjęcia</a>
    <a href=\"#\">Ustawienia konta</a>
    <a href=\"#\">Wyloguj</a>
</div>

";
        // line 48
        $this->loadTemplate("default/_flash_messages.html.twig", "base.html.twig", 48)->display($context);
        // line 49
        $this->displayBlock('body', $context, $blocks);
        // line 50
        echo "

";
        // line 52
        $this->displayBlock('javascripts', $context, $blocks);
        // line 61
        echo "</body>
</html>";
    }

    // line 8
    public function block_title($context, array $blocks = array())
    {
        echo "Default title";
    }

    // line 9
    public function block_stylesheets($context, array $blocks = array())
    {
        // line 10
        echo "        <!-- Bootstrap -->
        ";
        // line 12
        echo "              ";
        // line 13
        echo "        <link
                href=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/customStyle.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
        <link
                href=\"";
        // line 16
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/bootstrap.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
        <link
                href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css\" rel=\"stylesheet\" >
    ";
    }

    // line 41
    public function block_name($context, array $blocks = array())
    {
    }

    // line 49
    public function block_body($context, array $blocks = array())
    {
    }

    // line 52
    public function block_javascripts($context, array $blocks = array())
    {
        // line 53
        echo "    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script
            src=\"https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js\">1</script>
    <script
            src=\"";
        // line 57
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/bootstrap.min.js"), "html", null, true);
        echo "\"></script>
    <script
            src=\"";
        // line 59
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/scripts.js"), "html", null, true);
        echo "\"></script>
";
    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  141 => 59,  136 => 57,  130 => 53,  127 => 52,  122 => 49,  117 => 41,  109 => 16,  104 => 14,  101 => 13,  99 => 12,  96 => 10,  93 => 9,  87 => 8,  82 => 61,  80 => 52,  76 => 50,  74 => 49,  72 => 48,  64 => 42,  62 => 41,  39 => 20,  37 => 9,  33 => 8,  24 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "base.html.twig", "/home/h4ck3r/PhpstormProjects/Pro/app/templates/base.html.twig");
    }
}
