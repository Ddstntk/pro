<?php

/* bookmarks/view.html.twig */
class __TwigTemplate_875c55c1aa661fba833b75d59ed0b4a0192e47af4546111fd976251716b7ea5b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "bookmarks/view.html.twig"));

        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "bookmarks/view.html.twig"));

        // line 1
        echo "<h1>View Bookmark</h1>
";
        // line 2
        if ((array_key_exists("bookmark", $context) && twig_length_filter($this->env, ($context["bookmark"] ?? $this->getContext($context, "bookmark"))))) {
            // line 3
            echo "    <div>
        ";
            // line 4
            echo twig_escape_filter($this->env, $this->getAttribute(($context["bookmark"] ?? $this->getContext($context, "bookmark")), "title", array()), "html", null, true);
            echo ", ";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["bookmark"] ?? $this->getContext($context, "bookmark")), "url", array()), "html", null, true);
            echo "
    </div>
";
        } else {
            // line 7
            echo "    <div>
        No bookmark found!
    </div>
";
        }
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "bookmarks/view.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  41 => 7,  33 => 4,  30 => 3,  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<h1>View Bookmark</h1>
{% if bookmark is defined and bookmark|length %}
    <div>
        {{ bookmark.title }}, {{ bookmark.url }}
    </div>
{% else %}
    <div>
        No bookmark found!
    </div>
{% endif %}", "bookmarks/view.html.twig", "/home/h4ck3r/PhpstormProjects/Projekt2/app/templates/bookmarks/view.html.twig");
    }
}
