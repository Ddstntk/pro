<?php

/* posts/index.html.twig */
class __TwigTemplate_945c2af1b0f9995fa60143332f8ada78c8357f7fd4315b91b6aecfcb0d282723 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "posts/index.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        // line 4
        echo "    Posts
";
    }

    // line 7
    public function block_body($context, array $blocks = array())
    {
        // line 8
        echo "    ";
        $this->loadTemplate("default/_paginator.html.twig", "posts/index.html.twig", 8)->display(array_merge($context, array("paginator" =>         // line 9
(isset($context["paginator"]) ? $context["paginator"] : null), "route_name" => "posts_index_paginated")));
        // line 12
        echo "    ";
        if (($this->getAttribute((isset($context["paginator"]) ? $context["paginator"] : null), "data", array(), "any", true, true) && twig_length_filter($this->env, $this->getAttribute((isset($context["paginator"]) ? $context["paginator"] : null), "data", array())))) {
            // line 13
            echo "
            <div name=\"feed\" class=\"col-7 offset-md-1\">
                <div class=\"form-group\">
                    <label for=\"comment\"><h2>Posty:</h2></label>
                    <textarea class=\"form-control\" rows=\"5\" style=\"resize: none;\" id=\"comment\" placeholder=\"Napisz cos\"></textarea>
                    <button class=\"btn mt-3\">Dodaj post</button>
                </div>
                ";
            // line 20
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["paginator"]) ? $context["paginator"] : null), "data", array()));
            foreach ($context['_seq'] as $context["_key"] => $context["row"]) {
                // line 21
                echo "                    <div class=\"card w-100\" style=\"width: 18rem;\">
                        <div class=\"card-body\">
                            <h5 class=\"card-title\">idusers ";
                // line 23
                echo twig_escape_filter($this->env, $this->getAttribute($context["row"], "FK_idUsers", array()), "html", null, true);
                echo "</h5>
                            <h6 class=\"card-subtitle mb-2 text-muted\">Time</h6>
                            <p class=\"card-text\">";
                // line 25
                echo twig_escape_filter($this->env, $this->getAttribute($context["row"], "content", array()), "html", null, true);
                echo "</p>
                            <a href=\"#\" class=\"card-link\">idmedia ";
                // line 26
                echo twig_escape_filter($this->env, $this->getAttribute($context["row"], "idMedia", array()), "html", null, true);
                echo "</a>
                        </div>
                    </div>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['row'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 30
            echo "            </div>

    ";
        } else {
            // line 33
            echo "        <div>
            List is empty!
        </div>
    ";
        }
        // line 37
        echo "
";
    }

    public function getTemplateName()
    {
        return "posts/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 37,  88 => 33,  83 => 30,  73 => 26,  69 => 25,  64 => 23,  60 => 21,  56 => 20,  47 => 13,  44 => 12,  42 => 9,  40 => 8,  37 => 7,  32 => 4,  29 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "posts/index.html.twig", "/home/h4ck3r/PhpstormProjects/Pro/app/templates/posts/index.html.twig");
    }
}
