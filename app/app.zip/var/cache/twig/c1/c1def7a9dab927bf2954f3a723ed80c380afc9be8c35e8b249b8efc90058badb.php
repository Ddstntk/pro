<?php

/* posts/index.html.twig */
class __TwigTemplate_2a6b3df064bf4d3913e9e18eb731acd4bffd37c87e7b1038ea924737cba2b10d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "posts/index.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "posts/index.html.twig"));

        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "posts/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 4
        echo "    Posts
";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 7
    public function block_body($context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 8
        echo "    ";
        $this->loadTemplate("default/_paginator.html.twig", "posts/index.html.twig", 8)->display(array_merge($context, array("paginator" =>         // line 9
(isset($context["paginator"]) ? $context["paginator"] : $this->getContext($context, "paginator")), "route_name" => "posts_index_paginated")));
        // line 12
        echo "
    ";
        // line 13
        if (($this->getAttribute((isset($context["paginator"]) ? $context["paginator"] : null), "data", array(), "any", true, true) && twig_length_filter($this->env, $this->getAttribute((isset($context["paginator"]) ? $context["paginator"] : $this->getContext($context, "paginator")), "data", array())))) {
            // line 14
            echo "            <div class=\"customMyApp offset-md-2\">
            <div name=\"feed\" class=\"col-7 offset-md-1\">
                ";
            // line 17
            echo "                    ";
            // line 18
            echo "                    ";
            // line 19
            echo "                    ";
            // line 20
            echo "                ";
            // line 21
            echo "                ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["paginator"]) ? $context["paginator"] : $this->getContext($context, "paginator")), "data", array()));
            foreach ($context['_seq'] as $context["_key"] => $context["row"]) {
                // line 22
                echo "                    <div class=\"card w-100\" style=\"width: 18rem;\">
                        <div class=\"card-body\">
                            <h5 class=\"card-title\">idusers ";
                // line 24
                echo twig_escape_filter($this->env, $this->getAttribute($context["row"], "FK_idUsers", array()), "html", null, true);
                echo "</h5>
                            <h6 class=\"card-subtitle mb-2 text-muted\">";
                // line 25
                echo twig_escape_filter($this->env, $this->getAttribute($context["row"], "created_at", array()), "html", null, true);
                echo "</h6>
                            <p class=\"card-text\">";
                // line 26
                echo twig_escape_filter($this->env, $this->getAttribute($context["row"], "content", array()), "html", null, true);
                echo "</p>
                            <a href=\"#\" class=\"card-link\">idmedia ";
                // line 27
                echo twig_escape_filter($this->env, $this->getAttribute($context["row"], "idMedia", array()), "html", null, true);
                echo "</a>
                        </div>
                    </div>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['row'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 31
            echo "            </div>
            </div>
    ";
        } else {
            // line 34
            echo "        <div>
            List is empty!
        </div>
    ";
        }
        // line 38
        echo "
";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "posts/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  133 => 38,  127 => 34,  122 => 31,  112 => 27,  108 => 26,  104 => 25,  100 => 24,  96 => 22,  91 => 21,  89 => 20,  87 => 19,  85 => 18,  83 => 17,  79 => 14,  77 => 13,  74 => 12,  72 => 9,  70 => 8,  61 => 7,  50 => 4,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block title %}
    Posts
{% endblock %}

{% block body %}
    {% include 'default/_paginator.html.twig' with {
        paginator: paginator,
        route_name: 'posts_index_paginated',
    } %}

    {% if paginator.data is defined and paginator.data|length %}
            <div class=\"customMyApp offset-md-2\">
            <div name=\"feed\" class=\"col-7 offset-md-1\">
                {#<div class=\"form-group\">#}
                    {#<label for=\"comment\"><h2>Posty:</h2></label>#}
                    {#<textarea class=\"form-control\" rows=\"5\" style=\"resize: none;\" id=\"comment\" placeholder=\"Napisz cos\"></textarea>#}
                    {#<button class=\"btn mt-3\">Dodaj post</button>#}
                {#</div>#}
                {% for row in paginator.data %}
                    <div class=\"card w-100\" style=\"width: 18rem;\">
                        <div class=\"card-body\">
                            <h5 class=\"card-title\">idusers {{ row.FK_idUsers }}</h5>
                            <h6 class=\"card-subtitle mb-2 text-muted\">{{ row.created_at }}</h6>
                            <p class=\"card-text\">{{ row.content }}</p>
                            <a href=\"#\" class=\"card-link\">idmedia {{ row.idMedia }}</a>
                        </div>
                    </div>
                {% endfor %}
            </div>
            </div>
    {% else %}
        <div>
            List is empty!
        </div>
    {% endif %}

{% endblock %}", "posts/index.html.twig", "/home/h4ck3r/PhpstormProjects/Pro/app/templates/posts/index.html.twig");
    }
}
