<?php

/* base.html.twig */
class __TwigTemplate_1b478c7f9309b4c15a724dfc3b3bcdfdfec6928a3bb1829a09782531275a058c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'name' => array($this, 'block_name'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">
<head>
    <meta charset=\"utf-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>";
        // line 8
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
    ";
        // line 9
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 18
        echo "    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script
            src=\"https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js\"></script>
    <script
            src=\"https://oss.maxcdn.com/respond/1.4.2/respond.min.js\"></script>

    <![endif]-->
</head>
<body>

<div class=\"navbar fixed-top\">
    <a href=\"index.html\">Strona domowa</a>
    <a href=\"friends.html\">Znajomi</a>
    <a href=\"chat.html\">Wiadomości</a>
</div>

<div class=\"sidenav col-2\">
    <img class=\"img-fluid \" style=\"width: 100%\"
         src=\"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSxQhGXAcJBNKSrbAA3LowecuQDGJkxUHpOpu-t1dP0kctRBWYx\">
    ";
        // line 39
        $this->displayBlock('name', $context, $blocks);
        // line 40
        echo "    <a href=\"#\">Twój profil</a>
    <a href=\"#\">Zdjęcia</a>
    <a href=\"#\">Ustawienia konta</a>
    <a href=\"#\">Wyloguj</a>
</div>

";
        // line 46
        $this->loadTemplate("default/_flash_messages.html.twig", "base.html.twig", 46)->display($context);
        // line 47
        $this->displayBlock('body', $context, $blocks);
        // line 48
        $this->displayBlock('javascripts', $context, $blocks);
        // line 58
        echo "</body>
</html>";
    }

    // line 8
    public function block_title($context, array $blocks = array())
    {
        echo "Default title";
    }

    // line 9
    public function block_stylesheets($context, array $blocks = array())
    {
        // line 10
        echo "        <!-- Bootstrap -->
        <link
              href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css\" rel=\"stylesheet\">
        <link
                href=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/customStyle.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
        <link
                href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css\" rel=\"stylesheet\" >
    ";
    }

    // line 39
    public function block_name($context, array $blocks = array())
    {
    }

    // line 47
    public function block_body($context, array $blocks = array())
    {
    }

    // line 48
    public function block_javascripts($context, array $blocks = array())
    {
        // line 49
        echo "    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script
            src=\"https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js\"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script
            src=\"";
        // line 54
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/bootstrap.min.js"), "html", null, true);
        echo "\"></script>
    <script
            src=\"";
        // line 56
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/scripts.js"), "html", null, true);
        echo "\"></script>
";
    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  131 => 56,  126 => 54,  119 => 49,  116 => 48,  111 => 47,  106 => 39,  98 => 14,  92 => 10,  89 => 9,  83 => 8,  78 => 58,  76 => 48,  74 => 47,  72 => 46,  64 => 40,  62 => 39,  39 => 18,  37 => 9,  33 => 8,  24 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "base.html.twig", "/home/h4ck3r/PhpstormProjects/Pro/app/templates/base.html.twig");
    }
}
