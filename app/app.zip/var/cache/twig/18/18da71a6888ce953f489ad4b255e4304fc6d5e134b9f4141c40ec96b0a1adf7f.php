<?php

/* default/_paginator.html.twig */
class __TwigTemplate_9df72f82be9b4052d50759bd9ab8872c554605842b6a79e00592e45db6ec650c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/_paginator.html.twig"));

        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/_paginator.html.twig"));

        // line 4
        echo "<nav aria-label=\"...\">
    <ul class=\"pager\">
        ";
        // line 6
        if (($this->getAttribute(($context["paginator"] ?? $this->getContext($context, "paginator")), "page", array()) > 1)) {
            // line 7
            echo "            ";
            $context["previous"] = ($this->getAttribute(($context["paginator"] ?? $this->getContext($context, "paginator")), "page", array()) - 1);
            // line 8
            echo "            <li class=\"previous\">
                <a href=\"";
            // line 9
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getUrl(($context["route_name"] ?? $this->getContext($context, "route_name")), array("page" => ($context["previous"] ?? $this->getContext($context, "previous")))), "html", null, true);
            echo "\" title=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("labels.nav.prev"), "html", null, true);
            echo "\">
                    <span aria-hidden=\"true\">&larr;</span>";
            // line 10
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("labels.nav.prev"), "html", null, true);
            echo "
                </a>
            </li>
        ";
        } else {
            // line 14
            echo "            <li class=\"previous disabled\">
                <a href=\"#\" title=\"";
            // line 15
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("labels.nav.prev"), "html", null, true);
            echo "\">
                    <span aria-hidden=\"true\">&larr;</span>";
            // line 16
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("labels.nav.prev"), "html", null, true);
            echo "
                </a>
            </li>
        ";
        }
        // line 20
        echo "
        ";
        // line 21
        if (($this->getAttribute(($context["paginator"] ?? $this->getContext($context, "paginator")), "page", array()) < $this->getAttribute(($context["paginator"] ?? $this->getContext($context, "paginator")), "pages_number", array()))) {
            // line 22
            echo "            ";
            $context["next"] = ($this->getAttribute(($context["paginator"] ?? $this->getContext($context, "paginator")), "page", array()) + 1);
            // line 23
            echo "            <li class=\"next\">
                <a href=\"";
            // line 24
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getUrl(($context["route_name"] ?? $this->getContext($context, "route_name")), array("page" => ($context["next"] ?? $this->getContext($context, "next")))), "html", null, true);
            echo "\" title=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("label.nav.next"), "html", null, true);
            echo "\">
                    ";
            // line 25
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("label.nav.next"), "html", null, true);
            echo "<span aria-hidden=\"true\">&rarr;</span>
                </a>
            </li>
        ";
        } else {
            // line 29
            echo "            <li class=\"next disabled\">
                <a href=\"#\" title=\"";
            // line 30
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("label.nav.next"), "html", null, true);
            echo "\">
                    ";
            // line 31
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("label.nav.next"), "html", null, true);
            echo "<span aria-hidden=\"true\">&rarr;</span>
                </a>
            </li>
        ";
        }
        // line 35
        echo "    </ul>
</nav>";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "default/_paginator.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  102 => 35,  95 => 31,  91 => 30,  88 => 29,  81 => 25,  75 => 24,  72 => 23,  69 => 22,  67 => 21,  64 => 20,  57 => 16,  53 => 15,  50 => 14,  43 => 10,  37 => 9,  34 => 8,  31 => 7,  29 => 6,  25 => 4,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#
    Default view for paginator.
#}
<nav aria-label=\"...\">
    <ul class=\"pager\">
        {% if paginator.page > 1 %}
            {% set previous = (paginator.page - 1) %}
            <li class=\"previous\">
                <a href=\"{{ url(route_name, {'page': previous}) }}\" title=\"{{ 'labels.nav.prev'|trans }}\">
                    <span aria-hidden=\"true\">&larr;</span>{{ 'labels.nav.prev'|trans }}
                </a>
            </li>
        {% else %}
            <li class=\"previous disabled\">
                <a href=\"#\" title=\"{{ 'labels.nav.prev'|trans }}\">
                    <span aria-hidden=\"true\">&larr;</span>{{ 'labels.nav.prev'|trans }}
                </a>
            </li>
        {%  endif %}

        {% if paginator.page < paginator.pages_number %}
            {% set next = (paginator.page + 1) %}
            <li class=\"next\">
                <a href=\"{{ url(route_name, {'page': next}) }}\" title=\"{{ 'label.nav.next'|trans }}\">
                    {{ 'label.nav.next'|trans }}<span aria-hidden=\"true\">&rarr;</span>
                </a>
            </li>
        {% else %}
            <li class=\"next disabled\">
                <a href=\"#\" title=\"{{ 'label.nav.next'|trans }}\">
                    {{ 'label.nav.next'|trans }}<span aria-hidden=\"true\">&rarr;</span>
                </a>
            </li>
        {% endif  %}
    </ul>
</nav>", "default/_paginator.html.twig", "/home/h4ck3r/PhpstormProjects/Projekt2/app/templates/default/_paginator.html.twig");
    }
}
