<?php

/* user/view.html.twig */
class __TwigTemplate_59dc63b801c14f2d449cb239c455dcd5b7f13aa57c9cd5fb189e1092acc50cac extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "user/view.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
            'name' => array($this, 'block_name'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        // line 4
        echo "    Bookmarks
";
    }

    // line 7
    public function block_body($context, array $blocks = array())
    {
        // line 8
        echo "    ";
        $this->displayBlock('name', $context, $blocks);
        // line 9
        if ((array_key_exists("user", $context) && twig_length_filter($this->env, ($context["user"] ?? null)))) {
            // line 10
            echo "    <div>
        ";
            // line 11
            echo twig_escape_filter($this->env, $this->getAttribute(($context["user"] ?? null), "name", array()), "html", null, true);
            echo " ";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["user"] ?? null), "surname", array()), "html", null, true);
            echo ", ";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["user"] ?? null), "email", array()), "html", null, true);
            echo ", ";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["user"] ?? null), "idPicture", array()), "html", null, true);
            echo ", ";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["user"] ?? null), "access", array()), "html", null, true);
            echo ", ";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["user"] ?? null), "birthDate", array()), "html", null, true);
            echo "
    </div>
";
        } else {
            // line 14
            echo "    <div>
        No user found!
    </div>
";
        }
    }

    // line 8
    public function block_name($context, array $blocks = array())
    {
        echo "<h4>Witaj, ";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["user"] ?? null), "name", array()), "html", null, true);
        echo "! </h4>";
    }

    public function getTemplateName()
    {
        return "user/view.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 8,  65 => 14,  49 => 11,  46 => 10,  44 => 9,  41 => 8,  38 => 7,  33 => 4,  30 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "user/view.html.twig", "/home/h4ck3r/PhpstormProjects/Pro/app/templates/user/view.html.twig");
    }
}
