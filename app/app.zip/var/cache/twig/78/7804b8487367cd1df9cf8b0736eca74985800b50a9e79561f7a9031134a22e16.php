<?php

/* default/_paginator.html.twig */
class __TwigTemplate_04de679512965eab60b29da9bc69d4a5ed3e4134ba450c29c1a73db84c12ddb8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/_paginator.html.twig"));

        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/_paginator.html.twig"));

        // line 5
        echo "    ";
        // line 6
        echo "        ";
        // line 7
        echo "            ";
        // line 8
        echo "            ";
        // line 9
        echo "                ";
        // line 10
        echo "                    ";
        // line 11
        echo "                ";
        // line 12
        echo "            ";
        // line 13
        echo "        ";
        // line 14
        echo "            ";
        // line 15
        echo "                ";
        // line 16
        echo "                    ";
        // line 17
        echo "                ";
        // line 18
        echo "            ";
        // line 19
        echo "        ";
        // line 20
        echo "
        ";
        // line 22
        echo "            ";
        // line 23
        echo "            ";
        // line 24
        echo "                ";
        // line 25
        echo "                    ";
        // line 26
        echo "                ";
        // line 27
        echo "            ";
        // line 28
        echo "        ";
        // line 29
        echo "            ";
        // line 30
        echo "                ";
        // line 31
        echo "                    ";
        // line 32
        echo "                ";
        // line 33
        echo "            ";
        // line 34
        echo "        ";
        // line 35
        echo "    ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "default/_paginator.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  84 => 35,  82 => 34,  80 => 33,  78 => 32,  76 => 31,  74 => 30,  72 => 29,  70 => 28,  68 => 27,  66 => 26,  64 => 25,  62 => 24,  60 => 23,  58 => 22,  55 => 20,  53 => 19,  51 => 18,  49 => 17,  47 => 16,  45 => 15,  43 => 14,  41 => 13,  39 => 12,  37 => 11,  35 => 10,  33 => 9,  31 => 8,  29 => 7,  27 => 6,  25 => 5,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#
    Default view for paginator.
#}
{#<nav aria-label=\"...\">#}
    {#<ul class=\"pager\">#}
        {#{% if paginator.page > 1 %}#}
            {#{% set previous = (paginator.page - 1) %}#}
            {#<li class=\"previous\">#}
                {#<a href=\"{{ url(route_name, {'page': previous}) }}\" title=\"{{ 'labels.nav.prev'|trans }}\">#}
                    {#<span aria-hidden=\"true\">&larr;</span>{{ 'labels.nav.prev'|trans }}#}
                {#</a>#}
            {#</li>#}
        {#{% else %}#}
            {#<li class=\"previous disabled\">#}
                {#<a href=\"#\" title=\"{{ 'labels.nav.prev'|trans }}\">#}
                    {#<span aria-hidden=\"true\">&larr;</span>{{ 'labels.nav.prev'|trans }}#}
                {#</a>#}
            {#</li>#}
        {#{%  endif %}#}

        {#{% if paginator.page < paginator.pages_number %}#}
            {#{% set next = (paginator.page + 1) %}#}
            {#<li class=\"next\">#}
                {#<a href=\"{{ url(route_name, {'page': next}) }}\" title=\"{{ 'label.nav.next'|trans }}\">#}
                    {#{{ 'label.nav.next'|trans }}<span aria-hidden=\"true\">&rarr;</span>#}
                {#</a>#}
            {#</li>#}
        {#{% else %}#}
            {#<li class=\"next disabled\">#}
                {#<a href=\"#\" title=\"{{ 'label.nav.next'|trans }}\">#}
                    {#{{ 'label.nav.next'|trans }}<span aria-hidden=\"true\">&rarr;</span>#}
                {#</a>#}
            {#</li>#}
        {#{% endif  %}#}
    {#</ul>#}
{#</nav>#}", "default/_paginator.html.twig", "/home/h4ck3r/PhpstormProjects/Pro/app/templates/default/_paginator.html.twig");
    }
}
